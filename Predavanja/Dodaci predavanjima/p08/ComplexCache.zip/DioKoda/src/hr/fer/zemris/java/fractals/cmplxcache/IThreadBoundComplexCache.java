package hr.fer.zemris.java.fractals.cmplxcache;

public interface IThreadBoundComplexCache {
	
	IComplexCache getComplexCache();
	
}
