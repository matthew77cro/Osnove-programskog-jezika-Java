package hr.fer.zemris.java.fractals.cmplxcache;

public interface IComplexCacheProducer {
	IComplexCache getCache();
}
