package hr.fer.zemris.tecaj.swing.p01;

import javax.swing.JFrame;

public class OtvaranjeProzora {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		
		frame.setLocation(20, 20);
		frame.setSize(500, 200);
		
		frame.setVisible(true);
	}
}
