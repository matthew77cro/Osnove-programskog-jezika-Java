# Podesite stazu gdje je instaliran derby
DERBY_INSTALL=/home/marcupic/bin/db-derby-10.15.1.3-bin
# Podesite putanju do direktorija u kojem ce nastajati sve baze podataka
DERBY_DATABASES=/home/marcupic/tmp/derby-baze2

